#pragma once
#include <map>
#include <unordered_map>
#include <iostream>
using namespace std;

using Card = pair<string, int>;

// Cards class
class Cards {
public:
    Cards();

    Card selectCardFromDeck();  // Select a card randomly from the deck

private:
    unordered_map<int, Card> Deck;  // Map each card's point value to its corresponding card pair
};



