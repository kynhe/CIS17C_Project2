#include "Cards.hpp"

Cards::Cards() {

    //all the cards
    std::unordered_map<int, Card> Deck2 {
       {1, {"2 of Hearts", 2}},
       {2, {"3 of Hearts", 3}},
       {3, {"4 of Hearts", 4}},
       {4, {"5 of Hearts", 5}},
       {5, {"6 of Hearts", 6}},
       {6, {"7 of Hearts", 7}},
       {7, {"8 of Hearts", 8}},
       {8, {"9 of Hearts", 9}},
       {9, {"10 of Hearts", 10}},
       {10, {"Jack of Hearts", 10}},
       {11, {"Queen of Hearts", 10}},
       {12, {"King of Hearts", 10}},
       {13, {"Ace of Hearts", 11}},
       {14, {"2 of Diamonds", 2}},
       {15, {"3 of Diamonds", 3}},
       {16, {"4 of Diamonds", 4}},
       {17, {"5 of Diamonds", 5}},
       {18, {"6 of Diamonds", 6}},
       {19, {"7 of Diamonds", 7}},
       {20, {"8 of Diamonds", 8}},
       {21, {"9 of Diamonds", 9}},
       {22, {"10 of Diamonds", 10}},
       {23, {"Jack of Diamonds", 10}},
       {24, {"Queen of Diamonds", 10}},
       {25, {"King of Diamonds", 10}},
       {26, {"Ace of Diamonds", 11}},
       {27, {"2 of Clubs", 2}},
       {28, {"3 of Clubs", 3}},
       {29, {"4 of Clubs", 4}},
       {30, {"5 of Clubs", 5}},
       {31, {"6 of Clubs", 6}},
       {32, {"7 of Clubs", 7}},
       {33, {"8 of Clubs", 8}},
       {34, {"9 of Clubs", 9}},
       {35, {"10 of Clubs", 10}},
       {36, {"Jack of Clubs", 10}},
       {37, {"Queen of Clubs", 10}},
       {38, {"King of Clubs", 10}},
       {39, {"Ace of Clubs", 11}},
       {40, {"2 of Spades", 2}},
       {41, {"3 of Spades", 3}},
       {42, {"4 of Spades", 4}},
       {43, {"5 of Spades", 5}},
       {44, {"6 of Spades", 6}},
       {45, {"7 of Spades", 7}},
       {46, {"8 of Spades", 8}},
       {47, {"9 of Spades", 9}},
       {48, {"10 of Spades", 10}},
       {49, {"Jack of Spades", 10}},
       {50, {"Queen of Spades", 10}},
       {51, {"King of Spades", 10}},
       {52, {"Ace of Spades", 11}},
    };

    // Assign the initialized deck to the member variable Deck
    this->Deck = Deck2;
}

Card Cards::selectCardFromDeck() {

    // Select a random card index from the deck
    int randomCard = rand() % this->Deck.size();

    // Find the card in the deck at the selected index
    auto iter = Deck.begin();
    std::advance(iter, randomCard);

    // Retrieve the card from the iterator and store it in the ret variable
    Card ret = iter->second;

    // Remove the selected card from the deck
    Deck.erase(iter);

    // Return the selected card
    return ret;
}