#include <iostream>
#include <map>
#include <vector>
#include <random>
#include "Cards.hpp"

// Type alias for card probabilities
using CardProbabilities = std::map<Card, double>;

// Graph node structure
struct GNode {
	GNode(uint32_t _id) : id(_id) {}

	uint32_t id;
	CardProbabilities probabilities;
};

// Graph edge structure
struct GEdge {
	GEdge(GNode *_dest, GNode *_src) : src(_src), dest(_dest) {}

	GNode* src;
	GNode* dest;
};

// Graph class
class Graph {
public:
	Graph();

	void addNode(GNode*);  // Add a node to the graph
	void addEdge(GEdge*);  // Add an edge to the graph
	void Probability(GNode* node, Card card, double probability);  // Set probability for a node and card
	CardProbabilities simulateProbability(int);  // Simulate probabilities in the graph

private:
	std::vector<GNode*> _nodes;  // Vector to store graph nodes
	std::vector<GEdge*> _edges;  // Vector to store graph edges
};

