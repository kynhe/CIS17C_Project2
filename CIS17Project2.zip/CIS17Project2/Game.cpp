#include "Game.hpp"

// Recursive sort for vector of bot by money
void recursiveSortBot(std::vector<isBot>& buff, int start, int end) {
    if (start < end) {
        int pivot = start;
        int left = start + 1;
        int right = end;
        while (left <= right) {
            if (buff[left]->getTotalMoney() > buff[pivot]->getTotalMoney()
                && buff[right]->getTotalMoney() < buff[pivot]->getTotalMoney()) {
                std::swap(buff[left], buff[right]);
            }
            if (buff[left]->getTotalMoney() <= buff[pivot]->getTotalMoney()) {
                left++;
            }
            if (buff[right]->getTotalMoney() >= buff[pivot]->getTotalMoney()) {
                right--;
            }
        }
        std::swap(buff[pivot], buff[right]);
        recursiveSortBot(buff, start, right - 1);
        recursiveSortBot(buff, right + 1, end);
    }
}

Game::Game() {
    //===< Add bots in game >====
    uint32_t botAmount = 5;
    for (int i = 0; i < botAmount; i++) {
        this->botVec.push_back(make_unique<Bot>());
    }

    PlayersHash HPlayers(botVec.size() + 2);
    HPlayers.insert(1, this->player->getName());
    HPlayers.insert(2, this->dealer->getName());
    for (int i = 0; i < botVec.size(); i++)
        HPlayers.insert((i + 3), botVec[i]->getName());
    HPlayers.output();
}

void Game::richestOutput() {
    std::cout << "== RICHEST PLAYERS ==" << std::endl;

    for (int i = botVec.size() - 1; i >= 0; i--) {
        std::cout << botVec[i]->getName() << " [" << botVec[i]->getTotalMoney() << "]" << std::endl;
    }
    std::cout << std::endl << std::endl;
}

void Game::init() {
    std::cout << "- Black Jack - " << std::endl;
    recursiveSortBot(botVec, 0, botVec.size() - 1);
    richestOutput();

    // add current money in tree
    for (const auto& the : botVec)
        the->fixBalance();

    giveCards();

    this->totalCash += player->makeBet();
    this->totalCash += Bot1->makeBet();
    this->totalCash += Bot2->makeBet();

    isBlackJack();
    isLose();

    std::cout << std::endl << std::endl;
}

void Game::giveCards() {
    player->getCardFromDeck(this->cardsDeck->selectCardFromDeck());
    player->getCardFromDeck(this->cardsDeck->selectCardFromDeck());

    dealer->getCardFromDeck(this->cardsDeck->selectCardFromDeck());
    dealer->getCardFromDeck(this->cardsDeck->selectCardFromDeck());
}

void Game::checkDealer() {
    if (dealer->getScore() > 21) {
        cout << "You Won! +" << player->getCurrentBet() << endl;
        player->addMoney(player->getCurrentBet() * 2);
        checkResults();
        this->gameIsEnd = true;
    }
}

void Game::cardForDealer() {
    if (dealer->getScore() < 17) {
        dealer->getCardFromDeck(this->cardsDeck->selectCardFromDeck());
        dealer->getAllPlayersCards(this->dealer_result);
        checkDealer();
    }
}

void Game::update(uint32_t& repeat) {
    std::cout << "GAME MONEY: " << this->totalCash << std::endl << std::endl;
    player->info();
    cout << endl << endl;
    Bot1->info();
    Bot2->info();
    dealer->info();

    isBlackJack();

    switch (player->menu()) {
    case 1:
        player->getCardFromDeck(this->cardsDeck->selectCardFromDeck());
        player->getAllPlayersCards(this->player_result);
        break;
    case 2:
        playerStand();
        break;
    case 3:
        break;
    }

    cardForDealer();
    isBlackJack();
    isLose();

    repeat = endGame();
}

void Game::showGameList() {
    cout << endl << endl;

    while (!this->listOfGames.empty()) {
        string temp = listOfGames.front();
        cout << temp << endl;
        listOfGames.pop();
    }
}

void Game::isLose() {
    if (player->getScore() > 21) {
        cout << "You Lose!" << endl;
        this->listOfGames.push("Lose");
        checkResults();
        this->gameIsEnd = true;
        return;
    }
}

void Game::checkResults() {
    cout << "You: " << endl;
    cout << "##############" << endl;
    while (!this->player_result.empty()) {
        Card temp = player_result.top();
        std::cout << temp.first << " " << temp.second << std::endl;
        player_result.pop();
    }

    cout << endl << endl;

    cout << "Dealer: " << endl;
    cout << "##############" << endl;
    while (!this->dealer_result.empty()) {
        Card temp = dealer_result.top();
        std::cout << temp.first << " " << temp.second << std::endl;
        dealer_result.pop();
    }
    cout << endl << endl;

    this->scoreOnEnd[this->player->getScoreSum()] = "You";
    this->scoreOnEnd[this->dealer->getScoreSum()] = "Dealer";

    cout << endl;
    cout << "---------------------------" << endl;

    auto iter = this->scoreOnEnd.rbegin();
    for (iter; iter != this->scoreOnEnd.rend(); iter++) {
        cout << iter->second << " " << iter->first << endl;
    }
    cout << endl;
}

void Game::isDraw() {
    cout << "IT'S A DRAW!" << endl;
    this->listOfGames.push("Draw");
    checkResults();
    this->gameIsEnd = true;
    return;
}

void Game::playerStand() {
    cardForDealer();
    player->getAllPlayersCards(this->player_result);
    dealer->getAllPlayersCards(this->dealer_result);

    if (player->getScore() == dealer->getScore()) {
        isDraw();
    }
    else if (player->getScore() > dealer->getScore()) {
        cout << "You Won! +" << player->getCurrentBet() << endl;
        this->listOfGames.push("Won");
        checkResults();
        player->addMoney(player->getCurrentBet() * 2);
        this->gameIsEnd = true;
    }
    else {
        cout << "You Lose!" << endl;
        this->listOfGames.push("Lose");
        checkResults();
        this->gameIsEnd = true;
        return;
    }
}

void Game::isBlackJack() {
    if (player->getScore() == 21 && dealer->getScore() != 21) {
        player->getAllPlayersCards(this->player_result);
        dealer->getAllPlayersCards(this->dealer_result);

        cout << "Black Jack! +" << player->getCurrentBet() << endl;
        this->listOfGames.push("Black Jack");
        player->addMoney(player->getCurrentBet() * 2);
        checkResults();
        this->gameIsEnd = true;
    }
}

void Game::refreshGameArea() {
    delete this->cardsDeck;
    this->cardsDeck = new Cards;
    this->totalCash = 0;
    this->scoreOnEnd.clear();
    player->reset();
    dealer->reset();
    Bot1->reset();
    Bot2->reset();
}

uint32_t Game::menu() {
    //options
    cout << "1] - Play" << endl;
    cout << "2] - History and exit" << endl;
    cout << "3] - Exit" << endl;
    uint32_t choice;
    cin >> choice;

    return choice;
}

uint32_t Game::endGame() {
    if (this->gameIsEnd) {
        refreshGameArea();
        this->gameIsEnd = false;
        return 0;
    }

    return 1;
}

PlayersHash::PlayersHash(int init) {
    this->_bucket = init;
    this->_Players = new std::list<HashItem>[_bucket];
}

void PlayersHash::insert(int key, const std::string& PlayerName) {
    HashItem item(key, PlayerName);
    int placeIndex = hashfunc(key);
    this->_Players[placeIndex].push_back(item);
    this->size++;
}

int PlayersHash::hashfunc(int key) {
    return key % this->_bucket;
}

void PlayersHash::remove(int key) {
    int placeIndex = hashfunc(key);
    list<HashItem>::iterator it;
    for (it = this->_Players[placeIndex].begin(); it != this->_Players[placeIndex].end(); it++) {
        if (it->_key == key)
            break;
    }
    if (it != this->_Players[placeIndex].end())
        this->_Players[placeIndex].erase(it);
}

void PlayersHash::output() {
    std::cout << "====< PLAYERS IN THE GAME [" << this->size << "] >====" << std::endl;
    for (int i = 0; i < this->_bucket; i++) {
        for (const auto& the : this->_Players[i]) {
            std::cout << the._key << "] " << the._name << " " << std::endl;
        }
    }
    std::cout << std::endl << std::endl;
}
