#include "Bot.hpp"

Bot::Bot() {

    // Select a random index from botNames array
    int botNameIndex = rand() % botNames.size();
    this->name = botNames[botNameIndex];
    
    // Generate a random value for TotalMoney (between 0 and 99,999)
    this->TotalMoney = rand() % 100000;

    // Add the current TotalMoney to the binary tree
    this->moneyTracking.insert(this->TotalMoney);
}

void Bot::fixBalance() {
    // Add the current TotalMoney to the binary tree
    this->moneyTracking.insert(this->TotalMoney);
}

// Place a random bet
uint32_t Bot::makeBet() {

    // Generate a random bet value between 1 and 1,000
    uint32_t randomBet = rand() % 1000 + 1;
    this->bet = randomBet;

    // Deduct the bet amount from TotalMoney
    this->TotalMoney -= randomBet;

    // Return the bet amount
    return this->bet;
}

void Bot::changeBalance() {
    // Deduct the current bet amount from TotalMoney
    this->TotalMoney -= this->getCurrentBet();
}

uint32_t Bot::getTotalMoney() {
    // Return the current TotalMoney value
    return this->TotalMoney;
}

std::string Bot::getName() {
    // Return the bot's name
    return this->name;
}

// Display bot's information
void Bot::info() {
    cout << this->name << "[" << this->TotalMoney << "]" << endl;
    cout << "Bet: " << this->bet << endl << endl;
}

BotTree::BotTree() {
    // Initialize the root of the binary tree to nullptr
    this->root = nullptr;
}

bool BotTree::isEmpty() {
    // Check if the binary tree is empty (root is nullptr)
    return (this->root == nullptr);
}

void BotTree::insert(uint32_t currentMoney) {
    // Create a new TreeNode with currentMoney as the value
    TreeNode* newNode = new TreeNode(currentMoney);

    if (isEmpty()) {
        // If the tree is empty, make the new node as the root
        root = newNode;
    }
    else {
        TreeNode* node = root;
        TreeNode* prev = nullptr;

        while (node != nullptr) {
            prev = node;
            if (currentMoney > node->momentMoney) {
                // If currentMoney is greater than the node's momentMoney, go to the right subtree
                node = node->right;
            }
            else {
                // If currentMoney is less than or equal to the node's momentMoney, go to the left subtree
                node = node->left;
            }
        }

        if (currentMoney < prev->momentMoney) {
            // Insert the new node as the left child of the previous node
            prev->left = newNode;
        }
        else {
            // Insert the new node as the right child of the previous node
            prev->right = newNode;
        }
    }
}
