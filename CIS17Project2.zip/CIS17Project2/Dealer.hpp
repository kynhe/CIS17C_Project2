#pragma once
#include <iostream>
#include "Player.hpp"

using namespace std;

// Dealer class, derived from the Player class
class Dealer : public Player {

public:
    void isNeedCard();  // Determine whether the dealer needs to take another card
    void withHiddenCard();  // Display the dealer's hand with one card hidden
    void info();  // Display the dealer's name and other relevant information
    std::string getName();  // Get the name of the dealer

private:
    const string name = "Dealer";  // Name of the dealer (constant)
};
