#include "Dealer.hpp"

void Dealer::info() {

    // Print the dealer's name surrounded by "######"
    cout << "###### " << this->name << " ######" << endl;

    // Print "cards:" to indicate the following card information
    cout << "cards: " << endl;

    // Iterate over each card in the Cards unordered_map
    for (const auto& the : this->Cards) {

        // Print the card index (the.first) and the card description (the.second)
        cout << the.first << " " << "(" << the.second << ")" << endl;

        // Print "NEXT CARD HIDDEN" to indicate the next card is hidden
        cout << "NEXT CARD HIDDEN " << endl << endl << endl;

        // Exit the loop after printing the first card (break statement)
        break;
    }
}

std::string Dealer::getName() {
    // Return the dealer's name
    return this->name;
}
