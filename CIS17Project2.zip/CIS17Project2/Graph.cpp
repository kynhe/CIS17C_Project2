#include "Graph.hpp"

Graph::Graph() { }

void Graph::addNode(GNode *node) {
    this->_nodes.push_back(node);
}

void Graph::addEdge(GEdge* edge) {
    this->_edges.push_back(edge);
}

void Graph::Probability(GNode* node, Card card, double probability) {
    node->probabilities[card] = probability;
}

CardProbabilities Graph::simulateProbability(int iter) {
    // Create a map to store the amount of each card encountered
    std::map<Card, int> amount;
    
    // Initialize the card amount to 0 for each node's probabilities
    for (const auto& node : this->_nodes) {
        for (const auto& entry : node->probabilities) {
            amount[entry.first] = 0;
        }
    }

    // Random generator
    std::random_device randDevice;
    std::mt19937 rnd_mt(randDevice());
    std::uniform_real_distribution<double> dist(0.0, 1.0);

    // Pseudo simulation
    for (int i = 0; i < iter; ++i) {
        GNode* current = this->_nodes[0];

        while (current->id != this->_nodes.back()->id) {
            // Generate a random number between 0 and 1
            double r = dist(randDevice);
            double cumulativeProb = 0.0;

            // Traverse the probabilities of the current node
            for (const auto& entry : current->probabilities) {
                cumulativeProb += entry.second;

                // If the random number falls within the cumulative probability,
                // follow the corresponding edge to the next node
                if (r <= cumulativeProb) {
                    for (const auto& edge : this->_edges) {
                        if (edge->src == current && edge->dest->id == entry.second) {
                            current = edge->dest;
                            break;
                        }
                    }
                    break;
                }
            }
        }

        // Increase the amount for the card encountered at the final node
        for (const auto& entry : current->probabilities) {
            amount[entry.first]++;
        }
    }

    // Calculate the probabilities based on the card amounts
    CardProbabilities result;
    for (const auto& entry : amount) {
        result[entry.first] = static_cast<double>(entry.second) / iter;
    }

    return result;
}
