#pragma once
#include <iostream>
#include <functional>
#include <vector>

#include "Player.hpp"
#include "Graph.hpp"

using namespace std;

struct TreeNode {

	TreeNode() {}
	TreeNode(uint32_t money) : momentMoney(money), left(nullptr), right(nullptr) {}

	uint32_t momentMoney;  // Money value at this tree node
	TreeNode* left;        // Pointer to the left child node
	TreeNode* right;       // Pointer to the right child node
};

struct BotTree {
	TreeNode* root;

	BotTree();

	bool isEmpty();

	void insert(uint32_t);

	void showTreeInfo();
};

// Bot class, which is a subclass of the Player class.
class Bot : public Player {

public:
	// Computer-controlled player

	Bot();

	// Override info()
	void info();

	uint32_t makeBet();

	std::string getName();

	uint32_t getTotalMoney();

	void changeBalance();

	void fixBalance();

private:
	string name;            // Name of the bot
	int TotalMoney;         // Total money of the bot

	Graph graphSteps;       // Graph representing possible steps for the bot
	BotTree moneyTracking;  // Binary tree for tracking the bot's money

	// Names for bots (choice is random)
	std::vector<std::string> botNames {
		"Mark", "Grace", "Tarn", "Teresa", "Gabriela"
	};
};

