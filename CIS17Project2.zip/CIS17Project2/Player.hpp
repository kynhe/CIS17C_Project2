#pragma once
#include <iostream>
#include <set>
#include <queue>
#include <stack>

using namespace std;

using Card = pair<string, int>;

// Player class
class Player {
public:
	Player();

	virtual uint32_t makeBet();  // Make a bet
	uint32_t getScore();  // Get the player's score
	uint32_t getCard();  // Get a card
	virtual std::string getName();  // Get the player's name
	uint32_t getMoney();  // Get the player's money
	uint32_t getCurrentBet();  // Get the current bet
	uint32_t menu();  // Show a menu for player actions
	void getAllPlayersCards(stack<Card>&);  // Get all player cards
	void getCardFromDeck(Card);  // Get a card from the deck
	uint32_t getScoreSum();  // Get the sum of scores
	void showMyCards();  // Show the player's cards
	virtual void info();  // Show player information
	void reset();  // Reset player's data
	void isBlackJack();  // Check if the player has blackjack
	void addMoney(uint32_t);  // Add money to the player's balance
	void isWin();  // Handle winning condition
	virtual bool isLose();  // Check if the player has lost

protected:
	set<Card> Cards;  // Set to store player's cards
	uint32_t score = { 0 };  // Player's score
	uint32_t bet = { 0 };  // Player's bet
	uint32_t cash = { 0 };  // Player's cash balance
};
