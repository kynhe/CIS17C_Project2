#pragma once
#include "Player.hpp"
#include "Cards.hpp"
#include "Bot.hpp"
#include "Dealer.hpp"

#include <stack>
#include <queue>
#include <vector>
#include <memory>
#include <list>
#include <deque>
#include <map>

using isBot = unique_ptr<Bot>;
using Card = pair<string, int>;

using namespace std;

// Blackjack game
class Game {
	
public:
	Game();

	void init();

	void update(uint32_t&);

	void giveCards();

	uint32_t endGame();

	void isDraw();

	void isLose();

	void cardForDealer();

	void playerStand();

	void checkDealer();

	uint32_t menu();

	void checkResults();

	void refreshGameArea();

	void isBlackJack();

	void showGameList();

	void richestOutput();

private:
	double totalCash = { 0 };  // Store the total amount of cash available for the game

	bool gameIsEnd = false;

	unique_ptr<Player> player = make_unique<Player>();  // Player object
	unique_ptr<Dealer> dealer = make_unique<Dealer>();  // Dealer object

	std::vector<isBot> botVec;  // Vector of bot objects

	// Uncomment if using a list of bot objects
	// list<isBot> listOfBot;

	unique_ptr<Bot> Bot1 = make_unique<Bot>();  // Bot object 1
	unique_ptr<Bot> Bot2 = make_unique<Bot>();  // Bot object 2

	queue<string> listOfGames;  // Queue to store game names

	stack<Card> player_result;  // Stack to store player's card results
	stack<Card> dealer_result;  // Stack to store dealer's card results

	map<uint32_t, string> scoreOnEnd;  // Map to store scores on game end

	Cards* cardsDeck = new Cards;  // Deck of cards used in the game
};

struct HashItem {
	HashItem();
	HashItem(int key, std::string name) : _key(key), _name(name) {}

	int _key;             // Key value
	std::string _name;    // Name value
};

// Contains all players in the game
class PlayersHash {

public:
	PlayersHash(int var);

	void insert(int, const std::string&);

	void remove(int);

	int hashfunc(int);

	void output();

private:
	int _bucket;                    // Number of buckets
	std::list<HashItem>* _Players;  // List of players

	uint32_t size = 0;              // Size of the hash table
};
