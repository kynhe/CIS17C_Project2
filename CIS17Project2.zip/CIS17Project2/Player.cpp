#include "Player.hpp"

Player::Player() {
    // Initialize the player's cash to 2000
    this->cash = 2000;
}

void Player::info() {
    // Display player information
    cout << "You: " << endl;
    cout << "Cards: " << endl;
    showMyCards();
}

uint32_t Player::getScore() {
    return this->score;
}

uint32_t Player::getScoreSum() {
    uint32_t sum = 0;

    // Calculate the sum of the card values
    for (const auto& the : this->Cards) {
        sum += the.second;
    }
    return sum;
}

uint32_t Player::menu() {
    // Display the menu options and get the player's choice
    cout << "1] HIT" << endl;
    cout << "2] Stand" << endl;

    uint32_t choice;
    cin >> choice;
    return choice;
}

void Player::isWin() {
    // Double the bet and add it to the player's cash
    addMoney(this->bet * 2);
    this->bet = 0;
}

uint32_t Player::getMoney() {
    return this->cash;
}

void Player::getCardFromDeck(Card card) {
    // Add a card to the player's hand and update the score
    this->Cards.insert(card);
    this->score += card.second;
}

void Player::showMyCards() {
    // Display the player's cards and their scores
    for (const auto& the : this->Cards) {
        std::cout << the.first << " " << "(" << the.second << ")" << std::endl;
    }

    std::cout << "Score: " << getScore();
}

void Player::reset() {
    // Reset the player's bet, score, and cards
    this->bet = 0;
    this->score = 0;
    this->Cards.clear();
}

uint32_t Player::getCurrentBet() {
    return this->bet;
}

void Player::isBlackJack() {
    // Check if the player has a blackjack and add the corresponding payout to their cash
    if (getScore() == 21) {
        std::cout << "# BLACK JACK #" << + (bet + (bet / 2)) << std::endl;
        addMoney((bet + (bet / 2)));
    }
}

bool Player::isLose() {
    // Check if the player's score is over 21, indicating a loss
    if (getScore() > 21) {
        return true;
    }
    else {
        return false;
    }
}

void Player::addMoney(uint32_t amount) {
    // Add the specified amount of money to the player's cash
    this->cash += amount;
}

std::string Player::getName() { 
    return std::string("[You]"); 
}

void Player::getAllPlayersCards(stack<Card> &buffer) {
    // Clear the buffer stack and add all the player's cards to it
    if (!buffer.empty()) {
        while (!buffer.empty()) {
            buffer.pop();
        }
    }
    for (const auto& the : this->Cards) {
        buffer.push(the);
    }
}

uint32_t Player::makeBet() {
    // Display the player's available money and get the bet amount
    cout << "Money: " << getMoney() << endl;

    uint32_t bet;
    std::cout << "Bet: "; std::cin >> bet;

    if (bet <= this->cash) {
        // Deduct the bet amount from the player's cash and set the current bet
        this->cash -= bet;
        this->bet = bet;
        return bet;
    }
    else {
        // Player does not have enough money, prompt again for a valid bet
        std::cout << "No money" << std::endl;
        makeBet();
    }
}
