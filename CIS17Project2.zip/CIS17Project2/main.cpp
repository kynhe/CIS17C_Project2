/* 
 * File:   main.cpp
 * Author: Grace Kim
 * CIS 17C SPRING 2023
 * Project 2 Blackjack
 * Created on June 6, 2023, 11:04 PM
 */

#include "Game.hpp"

int main() {
    // Seed the random number generator
    srand(time(NULL));

    // Create a new game instance
    Game* game = new Game();

    // Variable to control repeating the game
    bool repeatGame = false;

    // Initialize the game
    game->init();

    // Variable to store the player's choice
    uint32_t choice = 1;

    // Main game loop
    while (true) {
        // Check if the player's choice is 0 (game over or menu option)
        if (choice == 0) {
            // Get the player's choice from the menu and handle it accordingly
            choice = game->menu();
            switch (choice) {
                case 1:
                    // Player chooses to start a new game
                    choice = 1;
                    game->init();
                    break;

                case 2:
                    // Player chooses to show the game list and exit
                    game->showGameList();
                    return 0;
                    break;

                case 3:
                    // Player chooses to exit the game
                    return 0;
                    break;
            }
        }

        // Update the game based on the player's choice
        game->update(choice);
    }
}
